// finMax.cpp
#include<iostream>
using namespace std;

template<typename T>
T findMax(T a, T b){
    return (a>b) ? a : b;
}

int main(){
    cout << findMax<int>(20, 50)<<endl;
    cout << findMax<char>('a', 'b')<<endl;
    cout << findMax<float>(3.12f, 3.13f)<<endl;
    cout << findMax(1.11, 2.22)<<endl;
    return 0;
}