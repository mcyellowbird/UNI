Steps:

1. Install the Google Maps API:
   - Open CMD Prompt
   - Run: pip install -U googlemaps

2. Generate the test data, open Command Prompt in the Data folder, then run
   - python generateData.py