Name: Idries Eagle-Masuak
Student ID: 6868288
Email: iem651@uowmail.edu.au

Compiler: GNU c++ compiler

Code to compile: g++ file.cpp -o file
Code to run: ./file



Task 1-2: Because we cannot create an object from an abstract class

Task 2-2:
	a: This program illustrates the use of pointers
	b: Each class interacts with eachother, i.e. Worker & Company class has a contract
	c: The program will give an error when trying to build, as the Contract needs a worker and a company
	d: It overrides the initial contract, so the worker will have to have a list of contracts to manage this situation.
	   If a new worker wants to work for Bell, a new contract will need to be created 

Task 4-2: The 3 files have the exact same size
Task 4-3: All executables run without a library being present (Not meant to?)