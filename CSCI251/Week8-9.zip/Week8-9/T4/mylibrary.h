
void functionOne(int &one, int &two, int &three);
int functionTwo(int one, int two, int three);


