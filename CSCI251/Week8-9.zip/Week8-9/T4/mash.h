#ifndef _MASH_H_
#define _MASH_H_

#include<string>

std::string mash(std::string inputWord);

#endif

