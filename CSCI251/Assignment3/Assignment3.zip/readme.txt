Name: Idries Eagle-Masuak
Student ID: 6868288
Email: iem651@uowmail.edu.au

Compiler: GNU c++ compiler

Code to compile: g++ main.cpp  -o main
Code to run: ./main num len

Where 'num' is the number of paragraphs (Positive Integer)
And 'len' is a the number of characters each paragraph has (Positive Integer)