using namespace std;


struct Mechanics;

struct Claims;

void loadMechanics(string);

void loadClaims(string);

int normalDist(int, int);

void claimEval(string);

void Error(string);