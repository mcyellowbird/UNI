Name: Idries Eagle-Masuak
Student ID: 6868288
Email: iem651@uowmail.edu.au

Compiler: GNU c++ compiler

Code to compile: g++ main.cpp implement.cpp -o main
Code to run: ./main claims.txt mechanics.txt output.txt