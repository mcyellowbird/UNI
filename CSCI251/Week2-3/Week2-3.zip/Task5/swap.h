int swap(int *ptr1, int *ptr2);
int display(int array[]);