
functionOne(int &one, int &two, int &three);
functionTwo(int one, int two, int three);


