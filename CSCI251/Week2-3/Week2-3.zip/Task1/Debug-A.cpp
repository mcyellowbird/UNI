#include <iostream>
using namespace std;

int main()
{
  double val1, val2;
  cout << "Enter a value: ";
  cin >> val1;
  cout << "Enter another value: ";
  cin >> val2;
  cout << val1 << " + " << val2 << " = " << (val1 + val2) << endl;
  cout << val1 << " * " << val2 << " = " << (val1 * val2) << endl;
  system("pause");
}
