materialType(char mat);
dimensions(double width, double height, double depth);
calcPrice(double width, double height, double depth, char mat);
display(double price);