Name: Idries Eagle-Masuak
Student ID: 6868288
Email: iem651@uowmail.edu.au

Compiler: GNU c++ compiler

Code to compile Q1-Q3: g++ file.cpp -o file
Code to run: ./file