class Timer extends Time{
	public Timer(int h, int m, int s){
		super.Time(h, m, s);
	}
	public Timer(int m, int s){
		super.Time(m, s);
	}
	public Timer(int s){
		super.Time(s);
	}

	public setTimer(int h, int m, int s){

	}
	public setTimer(int m, int s){

	}
}