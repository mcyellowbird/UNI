Tested in Capa with the following command:
	java FileSystem
	AND
	java FileSystem -i
