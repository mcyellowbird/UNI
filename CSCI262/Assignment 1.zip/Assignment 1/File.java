public class File {
    String filename;
    int classification; // Classification level

    public File(String filename, int classification) {
        this.filename = filename;
        this.classification = classification;
    }
}